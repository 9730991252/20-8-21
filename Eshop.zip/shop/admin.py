from django.contrib import admin

# Register your models here.

from .models import Product,Category,Sub_Category,Customer,Cart,OrderDetail,OrderMaster,Seller,Order_Status,Staf




@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('id','name')

@admin.register(Sub_Category)
class Sub_CategoryAdmin(admin.ModelAdmin):
    list_display = ('id','name')


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ('id','product_name','sub_category','price','seller_name')


@admin.register(Customer)
class CustomerAdmin(admin.ModelAdmin):
    list_display = ('id', 'mobile','name','addrress')

@admin.register(Cart)
class CartAdmin(admin.ModelAdmin):
    list_display = ('id','mobile','product_id','qty','price','product_name')

@admin.register(OrderMaster)
class OrderMasterAdmin(admin.ModelAdmin):
    list_display = ('id','customer','mobile','name','addrress','total_price','status','ordered_date')

@admin.register(OrderDetail)
class OrderDetaildAdmin(admin.ModelAdmin):
    list_display = ('id','mobile','product','qty','price','product_name','orderfilter')


@admin.register(Seller)
class SellerAdmin(admin.ModelAdmin):
    list_display = ('id','shope_name','seller_name','shop_address','seller_mobile','pin','status')

@admin.register(Order_Status)
class Order_StatusAdmin(admin.ModelAdmin):
    list_display = ('id','name')

@admin.register(Staf)
class StafAdmin(admin.ModelAdmin):
    list_display = ('id', 'name','mobile','pin')